./makeproject project1
cd project1
./gradle build
./run.sh