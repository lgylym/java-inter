#!/bin/bash

#gradle build
#gradle clean
java -jar ./build/libs/*.jar
